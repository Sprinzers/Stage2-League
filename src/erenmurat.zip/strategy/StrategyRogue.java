package strategy;

import champion.Rogue;

public interface StrategyRogue {

    void doStrategy(Rogue rogue);
}
