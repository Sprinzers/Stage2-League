package strategy;

import champion.Pyromancer;

public interface StrategyPyromancer {

    void doStrategy(Pyromancer pyromancer);
}
