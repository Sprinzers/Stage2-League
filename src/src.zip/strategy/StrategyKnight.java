package strategy;

import champion.Knight;

public interface StrategyKnight {

    void doStrategy(Knight knight);
}
