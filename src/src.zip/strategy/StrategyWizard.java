package strategy;

import champion.Wizard;

public interface StrategyWizard {

    void doStrategy(Wizard wizard);
}
